#include "Merchant.h"
#include "Player.h"
#include "Room.h"
#include "Party.h"
#include <iostream>
#include <string>
using namespace std;

int main(){

    bool keyz[5];
    keyz[0]=true;
    string treasurez[12][3];

    Merchant inventory= Merchant();
    Player player=Player();
    Room room=Room();
    Party party=Party();
    

    Player player2=Player("John", 100, "Club", 1, 1);
    Merchant inventory2=Merchant(100, 10, 1, 1, 1, 5);
    Room room2=Room(2.0, keyz, 100, treasurez);

    player.setName("John");

    cout<<"Player info:"<<endl;
    cout<<"Player name: "<<player.getName()<<endl;
    cout<<"Player fullness: "<<player.getFullness()<<endl;
    cout<<"Player's weapon: "<<player.getWeapon()<<endl;
    cout<<"Player's armor: "<<player.getArmor()<<endl;
    cout<<"Player's status: "<<player.getStatus()<<endl;

    cout<<" "<<endl;

    cout<<"Player 2 info:"<<endl;
    cout<<"Player name: "<<player2.getName()<<endl;
    cout<<"Player fullness: "<<player2.getFullness()<<endl;
    cout<<"Player's weapon: "<<player2.getWeapon()<<endl;
    cout<<"Player's armor: "<<player2.getArmor()<<endl;
    cout<<"Player's status: "<<player2.getStatus()<<endl;



    cout<<" "<<endl;

    inventory.setIngredient(10);


    cout<<"Player 1 Inventory:"<<endl;
    cout<<"Player's gold: "<<inventory.getnumGold()<<endl;
    cout<<"Player's ingredients: "<<inventory.getIngredient()<<endl;
    cout<<"Player's weapons: "<<inventory.getWeapons()<<endl;
    cout<<"Player's armor: "<<inventory.getArmor()<<endl;
    cout<<"Player's cookware: "<<inventory.getCookware()<<endl;
    cout<<"Player's treasure: "<<inventory.getTreasures()<<endl;

    cout<<" "<<endl;

    cout<<"Player 2 Inventory:"<<endl;
    cout<<"Player's gold: "<<inventory2.getnumGold()<<endl;
    cout<<"Player's ingredients: "<<inventory2.getIngredient()<<endl;
    cout<<"Player's weapons: "<<inventory2.getWeapons()<<endl;
    cout<<"Player's armor: "<<inventory2.getArmor()<<endl;
    cout<<"Player's cookware: "<<inventory2.getCookware()<<endl;
    cout<<"Player's treasure: "<<inventory2.getTreasures()<<endl;


    cout<<" "<<endl;

    room.setRoom(1);

    cout<<"Room 1 info:"<<endl;
    cout<<"Room: "<<room.getRoom()<<endl;
    cout<<"Keys: "<<room.getKeyAt(0)<<endl;
    cout<<"Sorcer's Anger Level: "<<room.getSorcererAnger()<<endl;
    cout<<"Treasure's: "<<room.getTreasureAt(0,1)<<endl;

    cout<<" "<<endl;

    cout<<"Room 2 info:"<<endl;
    cout<<"Room: "<<room2.getRoom()<<endl;
    cout<<"Keys: "<<room2.getKeyAt(0)<<endl;
    cout<<"Sorcer's Anger Level: "<<room2.getSorcererAnger()<<endl;
    cout<<"Treasure's: "<<room2.getTreasureAt(0,1)<<endl;

    cout<<" "<<endl;


    cout<<"Party member: "<<party.getPartyMember(0).getName()<<endl;
    cout<<"Number of gold: "<<party.getGold()<<endl;
    cout<<"Amount of ingredients: "<<party.getIngredients()<<endl;
    cout<<"Amount of armor: "<<party.getNumArmor()<<endl;
    cout<<"Amount of weapons: "<<party.getNumWeapons()<<endl;
    cout<<"Amount of cookware: "<<party.getCookwareAt(1)<<endl;
    cout<<"Active members: "<<party.getActiveMembers()<<endl;
    cout<<"Treasures found: "<<party.getTreasureFoundAt(0,0)<<endl;

    return 0;
}